// Copyright 2024 ekelly

#ifndef _PROGRAM_3_FUNCTIONS_H_
#define _PROGRAM_3_FUNCTIONS_H_

const int kCols = 10;
// function to return the number of elements in a
// a double scripted array
int CountAboveAv(const double[][kCols], int);

// function to sort rows by the values in a given column
void SortByCol(double[][kCols], int, int, bool);

// function that 
void SortByRow(double[][kCols], int, int, bool);

// function that 
double MedianInCol(const double [][kCols], int, int);

// function that
int ModeInCol(const double [][kCols], int, int, double[]);

#endif