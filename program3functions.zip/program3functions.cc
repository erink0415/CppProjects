// Copyright 2024 ekelly
#include"program3functions.h"
#include"checkArraysMatch.h"
#include<iostream>
#include<iomanip>
#include<cmath>

int CountAboveAv(const double nums[][kCols], int rows) {
    double sum = 0;
    int index = 0;
    int bigger = 0;
    //find the mean
    for ( int i = 0; i < rows; ++i) {
        for ( int j = 0; j < 10; ++j) {
            sum += nums[i][j];
            index++;
        }
    }
    double mean = sum/index;
    // find amt of elements larger then mean
    for ( int i = 0; i < rows; ++i) {
        for ( int j = 0; j < 10; ++j) {
            if (nums[i][j] > mean ) {
                bigger++;
            }
        }
    }
    //return int of how many bigger elements
    return bigger;
}

// make entire row move
void SortByCol(double nums[][kCols], int rows, int col, bool ascending) {
    if ( ascending == true ) {
        for ( int go_to = rows - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( nums[i][col] > nums[i+1][col] ) {
                    // for loop to make entire row move
                    for ( int k = 0; k < kCols; ++k) {
                        double temp = nums[i][k];
                        nums[i][k] = nums[i + 1][k];
                        nums[i + 1][k] = temp;
                    }
                }
            }
        }
    }
    else if ( ascending == false ) {
        for ( int go_to = rows - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( nums[i][col] < nums[i+1][col] ) {
                    // for loop to make entire row move
                    for ( int k = 0; k < kCols; ++k) {
                        double temp = nums[i][k];
                        nums[i][k] = nums[i + 1][k];
                        nums[i + 1][k] = temp;
                    }
                }
            }
        }
    }
}

void SortByRow(double nums[][kCols], int rows, int sortRow, bool ascending) {
    if ( ascending == true ) {
        for ( int go_to = kCols - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( nums[sortRow][i] > nums[sortRow][i+1] ) {
                    // for loop to move entire column
                    for ( int k = 0; k < rows; ++k) {
                        double temp = nums[k][i];
                        nums[k][i] = nums[k][i+1];
                        nums[k][i+1] = temp;
                    }
                }
            }
        }
    }
    if ( ascending == false ) {
        for ( int go_to = kCols - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( nums[sortRow][i] < nums[sortRow][i+1] ) {
                    // for loop to move entire column
                    for ( int k = 0; k < rows; ++k) {
                        double temp = nums[k][i];
                        nums[k][i] = nums[k][i+1];
                        nums[k][i+1] = temp;
                    }
                }
            }
        }
    }
}

double MedianInCol(const double nums[][kCols], int rows, int col) {
    double temp[rows];
    if ( rows % 2 == 0 ) {
        // populate temp array to sort
        for ( int i = 0; i < rows; ++i) {
            temp[i] = nums[i][col];
        }
        // sort columns of chosen row in temp 
        for ( int go_to = rows - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( temp[i] > temp[i+1] ) {
                    double temps = temp[i];
                    temp[i] = temp[i + 1];
                    temp[i + 1] = temps;
                }
            }
        }
        // return median
        return ((temp[rows / 2 - 1]) + (temp[rows / 2])) / 2;
    } else {
        // median in odd rows
        double temp[rows];
        // populate temp array to sort
        for ( int i = 0; i < rows; ++i) {
            temp[i] = nums[i][col];
        }
        // sort columns of chosen row in temp 
        for ( int go_to = rows - 1; go_to > 0; --go_to ) {
            for ( int i = 0; i < go_to; ++i ) {
                if ( temp[i] > temp[i+1] ) {
                    double temps = temp[i];
                    temp[i] = temp[i + 1];
                    temp[i + 1] = temps;
                }
            }
            // return median
            return (temp[rows/2]);
        }
    }
    return 0;
}

int ModeInCol(const double nums[][kCols], int rows, int col, double modes[]) {
    int numOfModes = 0;
    int mostModes = 0;
    // array for duplicates to go into
    double temp[rows];
    // loop to count the number of duplicates
    for ( int i = 0; i < rows; ++i) {
        for ( int j = 0; j < i; ++j) {
            if ( nums[i][col] == nums[j][col] ) {
                temp[j]++;
                break;
            }
        }
        // if statement to make every number accounted for
        if ( temp[i] == 0 )
            temp[i] = 1;
    }
    // for loop to find which duplicates happen most
    for ( int i = 0; i < rows; ++i ) {
        if ( temp[i] > mostModes )
            mostModes = temp[i];
    }
    // for loop to count amount of modes
    for ( int i = 0; i < rows; ++i ) {
        if ( temp[i] == mostModes )
            numOfModes++;
    }
    // if statement to make return value 0 if too many modes
    if ( numOfModes > 2 ) {
        return 0;
    }
    // continue code to populate modes array
    for ( int i = 0; i < 2; ++i ) {
        if ( temp[i] == mostModes )
            modes[i] = nums[i][col];
    }
    return numOfModes;
}
