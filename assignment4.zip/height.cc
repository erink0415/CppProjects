// copyright 2024 ekelly
// implement height class member functions

#include"height.h"
#include<iostream>
using std::cout;
using std::endl;
#include<string>
using std::string;
using std::ostream;

// constructor
Height::Height(double value, string units) {
    if ( value < 0 ) {
        value = 0;
        SetValue(value);
    } else {
        SetValue(value);
    }
    if ( units == "inches" || units == "feet"
    || units == "centimeters" || units == "meters") {
        SetUnits(units);
    } else {
        units = "feet";
        SetUnits(units);
    }
}

// setters
bool Height::SetValue(double v) {
    if ( v >= 0 ) {
        value_ = v;
        return true;
    }
    return false;
}
bool Height::SetUnits(const string& u) {
    if ( u == "inches" || u == "feet"
    || u == "centimeters" || u == "meters") {
        units_ = u;
        return true;
    }
    return false;
}

// extras
void Height::ConvertUnits(const string& u) {
    if ( units_ == u || (u != "inches" &&
                         u != "feet" &&
                         u != "centimeters" &&
                         u != "meters") )
        return;
    if ( units_ == "inches" ) {
        if ( u == "feet" ) {
            value_ = value_ / 12;
        } else if ( u == "centimeters" ) {
            // conversion for inches to centimeters
            value_ = value_ * 2.54;
        } else if ( u == "meters" ) {
            // conversion factor for inches to meters
            value_ = value_ * 0.0254;
        }
    } else if ( units_ == "feet" ) {
        if ( u == "inches" ) {
            // conversion factor for feet to inches
            value_ = value_ * 12;
        } else if ( u == "centimeters" ) {
            // conversion factor for feet to centimeters
            value_ = value_ * 12 * 2.54;
        } else if ( u == "meters" ) {
            // conversion factor for feet to meters
            value_ = value_ * 0.3048;
        }
    } else if ( units_ == "centimeters" ) {
        if ( u == "inches" ) {
            // conversion factor for cm to inches
            value_ = value_ * 0.393701;
        } else if ( u == "feet" ) {
            // conversion factor for cm to feet
            value_ = value_ * 0.0328084;
        } else if ( u == "meters" ) {
            // converison factor for cm to meters
            value_ = value_ / 100;
        }
    } else if ( units_ == "meters" ) {
        if ( u == "inches" ) {
            // conversion factor for m to inches
            value_ = value_ * 39.3701;
        } else if ( u == "feet" ) {
            // conversion factor for m to feet
            value_ = value_ * 3.28084;
        } else if ( u == "centimeters" ) {
            // conversion factor for m to cm
            value_ = value_ * 100;
        }
    }
    units_ = u;
}

ostream& operator << (ostream& whereto, const Height& h) {
    whereto << h.value_ << " " << h.units_;
    return whereto;
}
