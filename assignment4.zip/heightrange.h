// copyright 2024 ekelly
// define height range

#ifndef _HEIGHTRANGE_H_
#define _HEIGHTRANGE_H_
#include<string>
#include<iostream>
#include"height.h"
using std::string;
using std::cout;
using std::endl;
using std::ostream;

class HeightRange {
 public:
    //  default constructor
    HeightRange();

    // constructor
    explicit HeightRange(const Height& h1, const Height& h2);

    // getters
    Height GetShortest() const { return smallest_height_; }
    Height GetTallest() const { return tallest_height_; }

    // setters
    void SetShortest(const Height& height);
    void SetTallest(const Height& height);

    // extras
    bool InRange(const Height& height, bool inclusive = true) const;

    Height Width() const;

 private:
    Height smallest_height_;
    Height tallest_height_;
};

#endif
