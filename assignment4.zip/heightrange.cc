// copyright 2024 ekelly
// implement HeightRange class member functions
#include"height.h"
#include"heightrange.h"
#include<iostream>
using std::cout;
using std::endl;
#include<string>
using std::string;
using std::ostream;

    // default constructor
    HeightRange::HeightRange() {
        smallest_height_.SetValue(0);
        tallest_height_.SetValue(0);
    }

    // constructor
    HeightRange::HeightRange(const Height& h1, const Height& h2) {
        Height h11;
        Height h22;
        if (h1.GetUnits() != h2.GetUnits()) {
            h11 = h1;
            h22 = h2;
            string units = "inches";
            h11.ConvertUnits(units);
            h22.ConvertUnits(units);
        }
        if (h11.GetValue() < h22.GetValue()) {
            smallest_height_ = h1;
            tallest_height_ = h2;
        } else {
            smallest_height_ = h2;
            tallest_height_ = h1;
        }
    }

    // setters
    void HeightRange::SetShortest(const Height& height) {
        // convert to the same units
        Height h11;
        Height h22;
        if (height.GetUnits() != tallest_height_.GetUnits()) {
            h11 = height;
            h22 = tallest_height_;
            string units = "inches";
            h11.ConvertUnits(units);
            h22.ConvertUnits(units);
            if (h22.GetValue() >= h11.GetValue()) {
            smallest_height_ = height;
        }
        } else if (tallest_height_.GetValue() >= height.GetValue()) {
            smallest_height_ = height;
        }
    }

    void HeightRange::SetTallest(const Height& height) {
        // convert to the same units
        Height h11;
        Height h22;
        string unit1 = height.GetUnits();
        string unit2 = smallest_height_.GetUnits();
        if (height.GetUnits() != smallest_height_.GetUnits()) {
            h11 = height;
            h22 = smallest_height_;
            string units = "inches";
            h11.ConvertUnits(units);
            h22.ConvertUnits(units);
            if (h11.GetValue() >= h22.GetValue()) {
            tallest_height_.SetUnits(unit1);
            tallest_height_ = height;
        }
        } else if (height.GetValue() >= smallest_height_.GetValue()) {
            tallest_height_.SetUnits(unit1);
            tallest_height_ = height;
        }
    }

    // extras
    bool HeightRange::InRange(const Height& height, bool inclusive) const {
        // convert to the same units
        Height h11;
        Height h22;
        Height h33;
        if (height.GetUnits() != smallest_height_.GetUnits()) {
            h11 = height;
            h22 = smallest_height_;
            h33 = tallest_height_;
            string units = "inches";
            h11.ConvertUnits(units);
            h22.ConvertUnits(units);
            h33.ConvertUnits(units);
            if ( inclusive ) {
            return (h11.GetValue() >= h22.GetValue())
            && (h11.GetValue() <= h33.GetValue());
        } else {
            return (h11.GetValue() > h22.GetValue())
            && (h11.GetValue() < h33.GetValue());
        }
        } else if ( inclusive ) {
            return (height.GetValue() >= smallest_height_.GetValue())
            && (height.GetValue() <= tallest_height_.GetValue());
        } else {
            return (height.GetValue() > smallest_height_.GetValue())
            && (height.GetValue() < tallest_height_.GetValue());
        }
    }

    Height HeightRange::Width() const {
        Height h11;
        Height h22;
        string units = tallest_height_.GetUnits();
        if (tallest_height_.GetUnits() != smallest_height_.GetUnits()) {
            h11 = tallest_height_;
            h22 = smallest_height_;
            h11.ConvertUnits(tallest_height_.GetUnits());
            h22.ConvertUnits(tallest_height_.GetUnits());
        }
        double width = h11.GetValue() - h22.GetValue();
        return Height(width, units);
    }
