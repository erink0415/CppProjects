// copyright 2024 ekelly
// define a height

#ifndef _HEIGHT_H_
#define _HEIGHT_H_

#include<string>
#include<iostream>
using std::string;
using std::cout;
using std::endl;
using std::ostream;

class Height {
// overload << operator
friend ostream& operator << (ostream& whereto, const Height&);

 public:
    // constructor
    explicit Height(double value = 0, string units = "feet");

    // getters
    double GetValue() const { return value_; }
    string GetUnits() const { return units_; }

    // setters
    bool SetValue(double value);
    bool SetUnits(const string& units);

    // extras
    void ConvertUnits(const string& units);

 private:
    double value_;
    string units_;
};

#endif
